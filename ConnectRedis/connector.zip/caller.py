from connector import consumer
consumer.delay()
